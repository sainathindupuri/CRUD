package com.icici.ibanking.model;

public class CustomerPojo {
	
	private String f; 
	private String l;
	private int a;
	private int id;

	
	
	public int getA() {
		return a;
	}
	public void setA(int a) {
		this.a = a;
	}

	
	
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getF() {
		return f;
	}
	public void setF(String f) {
		this.f = f;
	}
	public String getL() {
		return l;
	}
	public void setL(String l) {
		this.l = l;
	}
	
	
	
	

}
