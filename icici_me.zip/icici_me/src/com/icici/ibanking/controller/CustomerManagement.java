package com.icici.ibanking.controller;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.icici.ibanking.model.CustomerPojo;
import com.icici.ibanking.service.CustomerServiceImpl;

/**
 * Servlet implementation class CustomerManagement
 */
@WebServlet("/CustomerManagement")
public class CustomerManagement extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public CustomerManagement() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String ac = request.getParameter("act");

		if (ac != null) {
			if (ac.equals("ListCustomer")) {
				listCustomer(request, response);
			}
			else if(ac.equals("editCustomer")){
				try {
					editCustomer(request,response);
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			else if(ac.equals("deleteCustomer")){
				try {
					deleteCustomer(request,response);
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			else if(ac.equals("showCustomerForm")){
				showCustomerForm(request,response);
			}
			}
			 

		 else {
			listCustomer(request, response);
		}
	}


	

	

	private void showCustomerForm(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		RequestDispatcher rd=request.getRequestDispatcher("WEB-INF/customercreation.jsp");
		rd.forward(request, response);
	}
		
	

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		//rd.forward(request, response);
		// TODO Auto-generated method stub
		String ac=request.getParameter("act");
		if(ac!=null)
		{
			if(ac.equals("createCustomer"))
			{
				createCustomer(request,response);
			}
			if(ac.equals("updateCustomer"))
			{
				try {
					updateCustomer(request,response);
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
		
	}

	private void updateCustomer(HttpServletRequest request,
			HttpServletResponse response) throws SQLException {
		// TODO Auto-generated method stub
		int id = Integer.parseInt(request.getParameter("id"));
		String f = request.getParameter("fname");
		String l = request.getParameter("lname");
		int a = Integer.parseInt(request.getParameter("age"));
		CustomerPojo cust = new CustomerPojo();
		cust.setCus_id(id);
		cust.setFname(f);
		cust.setLname(l);
		cust.setAge(a);
		CustomerServiceImpl cus=new CustomerServiceImpl();
		cus.updateCustomer(cust);
		try {
			response.sendRedirect("./CustomerManagement?act=ListCustomer");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
	}

	private void createCustomer(HttpServletRequest request,
			HttpServletResponse response) {
		// TODO Auto-generated method stub
		
		String fname=request.getParameter("fname");
		String lname=request.getParameter("lname");
		int age=Integer.parseInt(request.getParameter("age"));
		CustomerServiceImpl cus=new CustomerServiceImpl();
		try {
			cus.createCustomner(fname, lname, age);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		//RequestDispatcher rd=request.getRequestDispatcher("ListCustomer.jsp");
		try {
			response.sendRedirect("CustomerManagement?act=ListCustomer");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	private void listCustomer(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		CustomerServiceImpl cus=new CustomerServiceImpl();
		List<CustomerPojo> list = null;
		try {
			list = cus.CustomerList();
			request.setAttribute("cus_list", list);
			System.out.println("1");
			RequestDispatcher rd=request.getRequestDispatcher("WEB-INF/ListCustomer.jsp");
			rd.forward(request, response);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		// TODO Auto-generated method stub
		
	}
	private void editCustomer(HttpServletRequest request,
			HttpServletResponse response) throws SQLException, ServletException, IOException {
		// TODO Auto-generated method stub
		int id=Integer.parseInt(request.getParameter("cus_id"));
		CustomerServiceImpl cus=new CustomerServiceImpl();
		CustomerPojo cust=cus.getCustomer(id);
		
		RequestDispatcher rd=request.getRequestDispatcher("WEB-INF/EditForm.jsp");
		request.setAttribute("customerPojo", cust);
		rd.forward(request, response);
		
		
		
	}
	
	private void deleteCustomer(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException, SQLException {
		// TODO Auto-generated method stub
		int id=Integer.parseInt(request.getParameter("cus_id"));
		CustomerServiceImpl cus=new CustomerServiceImpl();
		cus.deleteCustomer(id);
		response.sendRedirect("./CustomerManagement?act=ListCustomer");
		
	}

}
