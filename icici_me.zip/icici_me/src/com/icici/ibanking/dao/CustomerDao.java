package com.icici.ibanking.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.icici.ibanking.model.CustomerPojo;

public class CustomerDao {
	private String jdbcURL;
	private String jdbcUsername;
	private String jdbcPassword;
	private Connection jdbcConnection;
	public void createCustomner(CustomerPojo cust) throws SQLException
	{
		CustomerPojo cus=new CustomerPojo();
		String sql="Insert into customer (first_name,lst_name,age) values (?,?,?)";
		connect();
		PreparedStatement statement=jdbcConnection.prepareStatement(sql);
		statement.setString(1, cust.getFname());
		statement.setString(2, cust.getLname());
		statement.setInt(3, cust.getAge());
		statement.executeUpdate();
		statement.close();
		jdbcConnection.close();
	}
	public List<CustomerPojo> CustomerList() throws SQLException
	{
		String sql="Select * from customer";
		connect();
		System.out.println("Connected");
		List<CustomerPojo>  list=new ArrayList<>();
		PreparedStatement statement=jdbcConnection.prepareStatement(sql);
		ResultSet rs=statement.executeQuery();
		while(rs.next())
		{
			CustomerPojo cus=new CustomerPojo();
			System.out.println("78"+rs.getInt(1));
			 int cus_id=(rs.getInt(1));
			 String fname=rs.getString(2);
			 String lname=rs.getString(3);
			 int age=(rs.getInt(4));
			 
			 cus.setCus_id(cus_id);
			 cus.setFname(fname);
			 cus.setLname(lname);
			 cus.setAge(age);
			 list.add(cus);
		}
		statement.close();
		jdbcConnection.close();
		System.out.println(list);
		return list;
		
	}

	protected void connect() throws SQLException {
		if (jdbcConnection == null || jdbcConnection.isClosed()) {
			try {
				Class.forName("com.mysql.jdbc.Driver");
			} catch (ClassNotFoundException e) {
				throw new SQLException(e);
			}
			jdbcConnection = DriverManager.getConnection(
					"jdbc:mysql://localhost:3306/db", "root", "root");
		}
	}
	public CustomerPojo getCustomer(int id) throws SQLException {
		// TODO Auto-generated method stub
		CustomerPojo cust=new CustomerPojo();
		String sql="select * from customer where cus_id=?";
		try {
			connect();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		PreparedStatement statement=jdbcConnection.prepareStatement(sql);
		statement.setInt(1,id);
		ResultSet rs=statement.executeQuery();
		while(rs.next())
		{
			int cusid = rs.getInt("cus_id");
			String fname = rs.getString("first_name");
			String lname = rs.getString("lst_name");
			int age = rs.getInt("age");
			cust.setCus_id(cusid);
			cust.setFname(fname);
			cust.setLname(lname);
			cust.setAge(age);
		}
		statement.close();
		jdbcConnection.close();
		return cust;
	}
	public void updateCustomer(CustomerPojo cust) throws SQLException {
		// TODO Auto-generated method stub
		String sql = "UPDATE customer SET first_name = ?, lst_name = ?, age = ?";
		sql += " WHERE cus_id = ?";
		connect();

		PreparedStatement ps = jdbcConnection.prepareStatement(sql);
		ps.setString(1, cust.getFname());
		ps.setString(2, cust.getLname());
		ps.setInt(3, cust.getAge());
		ps.setInt(4, cust.getCus_id());
		ps.executeUpdate();
		ps.close();
		jdbcConnection.close();
		
		
	}
	public void deleteCustomer(int id) throws SQLException {
		// TODO Auto-generated method stub
		String sql="Delete from customer where cus_id=?";
		connect();
		PreparedStatement ps = jdbcConnection.prepareStatement(sql);
		ps.setInt(1, id);
		ps.executeUpdate();
		ps.close();
		jdbcConnection.close();
		
		
	}

	}
