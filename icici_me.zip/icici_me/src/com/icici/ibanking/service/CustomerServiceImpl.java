package com.icici.ibanking.service;

import java.sql.SQLException;
import java.util.List;

import com.icici.ibanking.dao.CustomerDao;
import com.icici.ibanking.model.CustomerPojo;

public class CustomerServiceImpl {
	public void createCustomner(String fname,String lname,int age) throws SQLException
	{
		CustomerPojo cus=new CustomerPojo();
		cus.setFname(fname);
		cus.setLname(lname);
		cus.setAge(age);
		CustomerDao cust=new CustomerDao();
		cust.createCustomner(cus);
	}
	public List<CustomerPojo> CustomerList() throws SQLException
	{
		CustomerDao obj=new CustomerDao();
		List<CustomerPojo> list=obj.CustomerList();
		return list;
		
	}
	public void updateCustomer(CustomerPojo cust) throws SQLException {
		// TODO Auto-generated method stub
		CustomerDao obj=new CustomerDao();
		obj.updateCustomer(cust);
		
	}
	public CustomerPojo getCustomer(int id) throws SQLException {
		// TODO Auto-generated method stub
		CustomerDao obj=new CustomerDao();
		CustomerPojo cust=obj.getCustomer(id);
		return cust;
	}
	public void deleteCustomer(int id) throws SQLException {
		// TODO Auto-generated method stub
		CustomerDao obj=new CustomerDao();
		obj.deleteCustomer(id);
		
	}

}
