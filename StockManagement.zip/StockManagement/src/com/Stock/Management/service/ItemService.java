package com.Stock.Management.service;

import java.sql.SQLException;
import java.util.List;

import com.Stock.Management.dao.ItemDao;
import com.Stock.Management.model.Item;

public class ItemService {
	public void create(String name,int quantity,int price,String description) throws SQLException
	{
		Item item=new Item();
		item.setName(name);
		item.setQuantity(quantity);
		item.setPrice(price);
		item.setDescription(description);
		ItemDao dao=new ItemDao();
		dao.create(item);
	}

	public List<Item> StockList() throws SQLException {
		// TODO Auto-generated method stub
		ItemDao dao=new ItemDao();
		List<Item> itemlist=dao.itemList();
		return itemlist;
	}

	public Item getItem(int id) throws SQLException {
		ItemDao dao=new ItemDao();
		Item item=dao.getItem(id);
		return item;
		// TODO Auto-generated method stub
		
	}

	public void updateItem(Item item) throws SQLException {
		// TODO Auto-generated method stub
		ItemDao dao=new ItemDao();
		dao.updateItem(item);
	}

	public void deleteItem(int id) throws SQLException {
		// TODO Auto-generated method stub
		ItemDao dao=new ItemDao();
		dao.deleteItem(id);
		
	}

}
