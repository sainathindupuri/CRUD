package com.Stock.Management.dao;
import org.apache.log4j.Logger;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.Stock.Management.model.Item;







public class ItemDao {
	private Logger logger = Logger.getLogger(ItemDao.class);
	private String jdbcURL;
	private String jdbcUsername;
	private String jdbcPassword;
	private Connection jdbcConnection;

	protected void connect() throws SQLException {
		if (jdbcConnection == null || jdbcConnection.isClosed()) {
			try {
				Class.forName("com.mysql.jdbc.Driver");
			} catch (ClassNotFoundException e) {
				throw new SQLException(e);
			}
			jdbcConnection = DriverManager.getConnection(
					"jdbc:mysql://localhost:3306/stock", "root", "root");
		}
	}

	public void create(Item item) throws SQLException {
		// TODO Auto-generated method stub
		
		
		String sql="insert into items (name,quantity,price,description) values (?,?,?,?)";
		connect();
		PreparedStatement ps=jdbcConnection.prepareStatement(sql);
		ps.setString(1, item.getName());
		ps.setInt(2, item.getQuantity());
		ps.setInt(3, item.getPrice());
		ps.setString(4, item.getDescription());
		ps.executeUpdate();
		ps.close();
		jdbcConnection.close();
		
		
	}

	public List<Item> itemList() throws SQLException {
		// TODO Auto-generated method stub
		String sql="Select * from items";
		connect();
		logger.debug("inside create method");
		List<Item>  list=new ArrayList<>();
		PreparedStatement statement=jdbcConnection.prepareStatement(sql);
		ResultSet rs=statement.executeQuery();
		while(rs.next())
		{
			Item item=new Item();
			int id=rs.getInt(1);
			String name=rs.getString(2);
			int quantity=rs.getInt(3);
			int price=rs.getInt(4);
			String description=rs.getString(5);
			item.setItem_id(id);;
			item.setName(name);
			item.setPrice(price);
			item.setQuantity(quantity);
			item.setDescription(description);
			list.add(item);
		}
		return list;
	}

	public Item getItem(int id) throws SQLException {
		// TODO Auto-generated method stub
		String sql="Select * from items where item_id=?";
		connect();
		PreparedStatement statement=jdbcConnection.prepareStatement(sql);
		statement.setInt(1, id);
		ResultSet rs=statement.executeQuery();
		Item item=new Item();
		while(rs.next())
		{
		item.setItem_id(rs.getInt("item_id"));
		item.setName(rs.getString("name"));
		item.setPrice(rs.getInt("price"));
		item.setQuantity(rs.getInt("quantity"));
		item.setDescription(rs.getString("description"));
		}
		return item;
	}

	public void updateItem(Item item) throws SQLException {
		// TODO Auto-generated method stub
		String sql = "UPDATE items SET name = ?, quantity = ?, price = ?, description=?";
		sql += " WHERE item_id = ?";
		connect();
		PreparedStatement statement=jdbcConnection.prepareStatement(sql);
		statement.setString(1, item.getName());
		statement.setInt(2, item.getQuantity());
		statement.setInt(3, item.getPrice());
		statement.setString(4, item.getDescription());
		statement.setInt(5, item.getItem_id());
		statement.executeUpdate();
		statement.close();
		jdbcConnection.close();
	}

	public void deleteItem(int id) throws SQLException {
		// TODO Auto-generated method stub
		String sql="Delete from items where item_id=?";
		connect();
		PreparedStatement ps = jdbcConnection.prepareStatement(sql);
		ps.setInt(1, id);
		ps.executeUpdate();
		ps.close();
		jdbcConnection.close();
		
	}
	
	

}
