0package com.Stock.Management.controller;

import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.Stock.Management.model.Item;
import com.Stock.Management.service.ItemService;



/**
 * Servlet implementation class ItemController
 */
@WebServlet("/ItemController")
public class ItemController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ItemController() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String ac = request.getParameter("act");
		if(ac!=null)
		{
			if(ac.equals("showItemForm"))
			{
				showItemForm(request,response);
			}
			else if(ac.equals("StockList"))
			{
				try {
					StockList(request,response);
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			else if(ac.equals("editItem"))
			{
				try {
					showEdit(request,response);
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			else if(ac.equals("deleteItem"))
			{
				deleteItem(request,response);
			}
		}
	}

	private void deleteItem(HttpServletRequest request,
			HttpServletResponse response) {
		// TODO Auto-generated method stub
		int id=Integer.parseInt(request.getParameter("item_id"));
		ItemService service=new ItemService();
		try {
			service.deleteItem(id);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			response.sendRedirect("ItemController?act=StockList");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}

	private void showEdit(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException, SQLException {
		// TODO Auto-generated method stub
		int id=Integer.parseInt(request.getParameter("item_id"));
		ItemService service=null;
		try {
			service = new ItemService();
		} catch (Exception e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		Item item=service.getItem(id);
		request.setAttribute("Item", item);
		RequestDispatcher rd = null;
		try {
			rd = request.getRequestDispatcher("WEB-INF/EditForm.jsp");
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		rd.forward(request, response);
		
	}

	private void StockList(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException, SQLException {
		// TODO Auto-generated method stub
		ItemService service=new ItemService();
		List<Item> itemlist=service.StockList();
		request.setAttribute("item_list", itemlist);
		RequestDispatcher rd=request.getRequestDispatcher("WEB-INF/ListItem.jsp");
		rd.forward(request, response);
		
	}

	private void showItemForm(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		RequestDispatcher rd=request.getRequestDispatcher("WEB-INF/ItemCreation.jsp");
		rd.forward(request, response);
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		String ac = request.getParameter("act");
		if(ac!=null)
		{
			if(ac.equals("createItem"))
			{
				try {
					createItem(request,response);
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			else if(ac.equals("updateItem"))
			{
				try {
					updateItem(request,response);
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
	}

	private void createItem(HttpServletRequest request,
			HttpServletResponse response) throws SQLException, IOException {
		// TODO Auto-generated method stub
		String name=request.getParameter("name");
		int quantity=Integer.parseInt(request.getParameter("quantity"));
		int price=Integer.parseInt(request.getParameter("price")); 
		String description=request.getParameter("description");
		
		ItemService itemservice=new ItemService();
		itemservice.create(name,quantity,price,description);
		response.sendRedirect("ItemController?act=StockList");
		
	}
	private void updateItem(HttpServletRequest request,
			HttpServletResponse response) throws SQLException, IOException{
		Item item=new Item();
		int id=Integer.parseInt(request.getParameter("item_id"));
		item.setItem_id(id);
		item.setName(request.getParameter("name"));
		item.setPrice(Integer.parseInt(request.getParameter("price")));
		item.setQuantity(Integer.parseInt(request.getParameter("quantity")));
		item.setDescription(request.getParameter("description"));
		ItemService itemservice=new ItemService();
		itemservice.updateItem(item);
		response.sendRedirect("ItemController?act=StockList");
	}

}
